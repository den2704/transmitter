﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace transmitter
{
    class Program
    {
        static List<string> coords = new List<string>();
        static List<double> coords_f = new List<double>();
        static List<string> measure = new List<string>();
        static List<double> measure_f = new List<double>();

        static List<double> x_list = new List<double>();
        static List<double> y_list = new List<double>();

        static List<double> result_system3 = new List<double>();

        static double x1;
        static double y1;
        static double x2;
        static double y2;
        static double x3;
        static double y3;

        static string[] writeText = new string[20];
        static int writeTextNum = 0;

        static void System3(double d1_f, double d2_f, double d3_f) // решение системы из двух уравнений - второе для проверки
        {
            // (x-x1)**2 + (y-y1)**2 = (d1*10**6)**2
            // (x-x2)**2 + (y-y2)**2 = (d2*10**6)**2
            // (x-x3)**2 + (y-y3)**2 = (d3*10**6)**2

            // x**2 + y**2 - 2*x1*x - 2*y1*y = (d1*10**6)**2 - x1**2 - y1**2
            // x**2 + y**2 - 2*x2*x - 2*y2*y = (d2*10**6)**2 - x2**2 - y2**2
            // x**2 + y**2 - 2*x3*x - 2*y3*y = (d3*10**6)**2 - x3**2 - y3**2

            // вычитаем из второго третье
            // - 2*x2*x - 2*y2*y + 2*x3*x + 2*y3*y = (d2*10**6)**2 - x2**2 - y2**2 - (d3*10**6)**2 + x3**2 + y3**2
            double num = Math.Pow((d2_f * Math.Pow(10,6)),2) - Math.Pow(x2,2) - Math.Pow(y2,2) - Math.Pow((d3_f * Math.Pow(10, 6)),2) + Math.Pow(x3,2) + Math.Pow(y3,2);
            // 2*(-x2+x3)*x + 2*(-y2+y3)*y = num
            // x = ((num - 2*(-y2+y3)*y) / 2*(-x2+x3)) = a - b*y
            double a = num / (2 * (x3 - x2));
            double b = (y3 - y2) / (x3 - x2);

            // подставляем во второе x**2 + y**2 - 2*x2*x - 2*y2*y = (d2*10**6)**2 - x2**2 - y2**2
            double num2 = Math.Pow((d2_f * Math.Pow(10, 6)),2) - Math.Pow(x2,2) - Math.Pow(y2,2);

            // (a - b*y)**2 + y**2 - 2*x2*(a - b*y) - 2*y2*y = num2
            // a**2 - 2*a*b*y + b**2*y**2 + y**2 - 2*x2*a + 2*x2*b*y - 2*y2*y = num2
            // (b**2+1)*y**2 + (-2*a*b+2*x2*b-2*y2)*y + (a**2 - 2*x2*a - num2) = 0
            double l = Math.Pow(b,2) + 1;
            double m = -2 * a * b + 2 * x2 * b - 2 * y2;
            double n = Math.Pow(a, 2) - 2 * x2 * a - num2;
            double D = Math.Pow(m, 2) - 4 * l * n;

            double y_1;
            double y_2;
            double x_1;
            double x_2;

            if (D >= 0)
            {
                y_1 = (Math.Sqrt(D) - m) / (2 * l);
                y_2 = (-Math.Sqrt(D) - m) / (2 * l);
                x_1 = (num - 2 * (-y2 + y3) * y_1) / (2 * (-x2 + x3));
                x_2 = (num - 2 * (-y2 + y3) * y_2) / (2 * (-x2 + x3));

                // проверяем - укладывается ли d1 в диапазон 10%?
                // (x-x1)**2 + (y-y1)**2 = (d1*10**6)**2

                double left1 = Math.Pow((x_1 - x1), 2) + Math.Pow((y_1 - y1), 2);
                // right1 = ((d1_f*10**6)**2)

                double d1_f_v = Math.Sqrt(left1) / Math.Pow(10, 6);
                if (Math.Abs(d1_f_v - d1_f) < (0.1 * d1_f))
                {
                    // print('x_1', x_1, 'y_1', y_1)
                    x_list.Add(x_1);
                    y_list.Add(y_1);
                }

                left1 = Math.Pow((x_2 - x1), 2) + Math.Pow((y_2 - y1), 2);
                // right2 = ((d2_f * 10 ** 6) ** 2)

                d1_f_v = Math.Sqrt(left1) / Math.Pow(10, 6);
                if (Math.Abs(d1_f_v - d1_f) < (0.1 * d1_f))
                {
                    // print('x_2', x_2, 'y_2', y_2)
                    x_list.Add(x_2);
                    y_list.Add(y_2);
                }
            }

        }

        static void Answer3(double d1, double d2, double d3)
        {
            double d1_min = d1 - (0.05 * d1 / 2);
            double d1_max = d1 + (0.05 * d1 / 2);
            double d2_min = d2 - (0.05 * d2 / 2);
            double d2_max = d2 + (0.05 * d2 / 2);
            double d3_min = d3 - (0.05 * d3 / 2);
            double d3_max = d3 + (0.05 * d3 / 2);
            double d1_v = d1_min;
            double d2_v = d2_min;
            double d3_v = d3_min;
            double accuracy = 0.0000001;
            double x_av = 0;
            double y_av = 0;
            while (d1_v < d1_max)
            {
                while (d2_v < d2_max)
                {
                    while (d3_v < d3_max)
                    {
                        System3(d1_v, d2_v, d3_v);
                        d3_v += accuracy * d3;
                    }
                    d2_v += accuracy * d2;
                }
                d1_v += accuracy * d1;
            }
            double sum = 0;
            if (x_list.Count != 0)
            {
                foreach (double i in x_list) sum += i;
                x_av = sum / x_list.Count;
            }
            sum = 0;
            if (y_list.Count != 0)
            {
                foreach (double i in y_list) sum += i;
                y_av = sum / y_list.Count;
            }
            if (x_list.Count != 0 && y_list.Count != 0)
            {
                result_system3.Add(x_av);
                result_system3.Add(y_av);
                Console.WriteLine($"{x_av}, {y_av}");
                writeText[writeTextNum] = x_av.ToString() + "," + y_av.ToString();
                writeTextNum += 1;
                //writeText[writeTextNum] = y_av.ToString();
                //writeTextNum += 1;
            }
            x_list.Clear();
            y_list.Clear();
        }

        static void Main(string[] args)
        {
            string path = @"C:\job\input.txt";
            // считываем исходные данные из файла
            string[] readText = File.ReadAllLines(path, Encoding.UTF8);
            int qMeasure = 0;
            string numString = string.Empty;
            foreach (string s in readText)
            {           
                foreach (var c in s)
                {
                    if (c != ',')
                    {
                        numString = string.Concat(numString, c.ToString());
                    }
                    else
                    {
                        if (qMeasure == 0)
                        {
                            coords.Add(numString);
                        }
                        else
                        {
                            measure.Add(numString);
                        }
                        numString = string.Empty;
                    }
                }                
                if (qMeasure == 0)
                {
                    coords.Add(numString);
                }
                else
                {
                    measure.Add(numString);
                }
                qMeasure++;
                numString = string.Empty;
            }
            Console.WriteLine("Количество измерений:");
            Console.WriteLine(qMeasure-1);
            Console.WriteLine("Положение статичных приемников:");
            foreach (string o in coords)
            {
                Console.WriteLine(o);
                coords_f.Add(double.Parse(o.Replace(".", ",")));
            }
            x1 = coords_f[0];
            y1 = coords_f[1];
            x2 = coords_f[2];
            y2 = coords_f[3];
            x3 = coords_f[4];
            y3 = coords_f[5];
            Console.WriteLine();
            Console.WriteLine("Данные измерений:");
            foreach (string m in measure)
            {
                Console.Write(m);
                measure_f.Add(double.Parse(m.Replace(".", ",")));
                Console.Write(", ");
            }
            Console.WriteLine();
            Console.WriteLine("Результаты вычислений");
            for (int i = 0; i <= 27; i += 3)
            {                
                //Console.WriteLine($"{measure_f[i]}, {measure_f[i + 1]}, {measure_f[i + 2]}");
                Answer3(measure_f[i], measure_f[i+1], measure_f[i+2]);
            }
            string path_out = @"C:\job\my_output.txt";
            // записываем данные в файл
            File.WriteAllLines(path_out, writeText, Encoding.UTF8);
            Console.ReadKey();
        }
    }
}
