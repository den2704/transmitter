﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace transmitter
{
    public partial class Form1 : Form
    {
        static List<string> Points = new List<string>();
        static List<double> xyPoints = new List<double>();
        public Form1()
        {
            InitializeComponent();
            // берем данные из файла
            string path = @"C:\job\my_output.txt";
            // считываем исходные данные из файла
            string[] readText = File.ReadAllLines(path, Encoding.UTF8);
            string numString = string.Empty;
            foreach (string s in readText)
            {
                foreach (var c in s)
                {
                    if (c != '\t')
                    {
                        numString = string.Concat(numString, c.ToString());
                    }
                    else
                    {

                        Points.Add(numString);
                        Console.WriteLine(numString);
                        numString = string.Empty;
                    }
                }
                if (numString != "")
                {
                    Points.Add(numString);
                    Console.WriteLine(numString);
                }
                numString = string.Empty;
            }
            foreach (string o in Points)
            {
                //Console.WriteLine(o);
                xyPoints.Add(double.Parse(o));
            }
            // вывод данных
            for (int i=0; i+1 < 20; i += 2)
            {
                chart1.Series[0].Points.AddXY(xyPoints[i], xyPoints[i+1]);
            }
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
